# Acceptance status

| Requirement | Observed status |
|---|---|
| Real pinned SkillRet inspection | PASS; counts, schemas, binary qrels, integrity and provenance saved |
| Real BM25 number before API spend | PASS; Recall@5 0.516667 on 200 / 6,006 |
| Local vector and matched metadata BM25 | PASS; real CPU results with explicit caps |
| Real native metadata/tool isolation | PASS with scripted controller, effective prompts/tools captured |
| OpenRouter canary with actual usage | BLOCKED; missing local key and paid permission |
| Real listing/BM25/vector selector comparison | BLOCKED; offline candidate retrieval completed |
| Same-model query-only domain routing | BLOCKED; no substitute labels or fallback |
| Native SKILL.md read | PASS for real backend/tool reads under scripted control; live activation BLOCKED |
| Tests | 33 collected, 33 passed; prior failures retained |
| Exactly two executed notebooks | PASS; paid cells explicitly SKIPPED |
| Generated report/tables/three figures | PASS; generated from saved current-run results |
| Sanitized handoff | Allowlisted ZIP with checksums, no credentials/environments/bulk caches |

Overall: honest blocked pilot with completed offline evidence. The successful-live-pilot definition in CODEX_TASK.md has not been met.
