# Validation report

## Overall assessment: Share with caveats

The offline retrieval and native integration evidence is usable for a feasibility proposal. The intended live comparison remains blocked and must be described that way.

## Methodology and calculations

- Full-document BM25: 200 queries / 6,006 skills. Recomputed macro Recall@5 directly from saved top-five IDs and gold sets: 0.5166666667. Completeness@5: 75/200. No published-score reproduction claim.
- The local retrieval metric definitions agree with the pinned official evaluator on three small controls, including multiple positives and an empty ranking. MRR is explicitly a local addition. Three real rankings and their set intersections are saved in `evidence/manual_metric_checks.json`.
- All 180 available candidate-recall observations were independently recomputed from candidate/gold sets and reconciled with report CSVs. The 60 domain-vector rows are blocked, with no invented routing result.
- All 60 saved catalogue memberships are exact-size, nested and gold-preserving. The deterministic display order is independent of relevance. Pilot/final query IDs are disjoint. Qrels are observed binary relevance=1.
- Current report aggregates use one exact run configuration and one case per case key. Historical runs, including the incorrect early token-estimate diagnostic, are retained but excluded.
- Native discovery, tool isolation, terminal handling, actual native reads, budget persistence, reserves after ambiguous/missing-cost failures, tool transport, provider pinning, retry count, timeout units and adapter usage are tested. HTTP fixtures and scripted models are explicitly excluded from benchmark metrics.
- Current verification: 33 tests collected and passed. Both notebooks executed successfully with paid cells SKIPPED. See the exact logs and notebook execution JSON; no pytest exit status was masked.

## Visual review

The three standalone figures distinguish candidate recall from final selector accuracy and provider-reported tokens. Missing live metrics are shown as unavailable, with no fabricated zero-valued points. The candidate chart states n=20 queries per point and the missing paid domain router. A footer overlap found during image inspection was corrected before final export.

## Required caveats and incomplete handoff milestones

- No local OpenRouter key/paid permission: zero paid requests, zero actual USD spend, zero estimated CAD spend at the 1.50 planning factor. Live canary, selector comparison, domain router and live activation are unrun.
- Five actual native read checks used scripted model control; they establish disclosure wiring only, never task execution success.
- Seven embedding queries exceeded the encoder's 512-token limit. Character/token metadata caps are explicit and shared. The full-document baseline uses different input representation.
- Token-template estimates and context margins are planning/preflight evidence, not billed counts. N=1,000 listing is conservatively excluded at the current endpoint; no catalogue was silently truncated or summarized.
- Small conditional libraries, random distractors, synthetic queries, public-source skills and software-domain skew limit external validity. No p-values or broad superiority claim is justified.

## Required next action

Run the private key helper and `bash scripts/resume.sh` locally. Do not paste a credential into chat. The persistent ledger and budget guards remain mandatory.
