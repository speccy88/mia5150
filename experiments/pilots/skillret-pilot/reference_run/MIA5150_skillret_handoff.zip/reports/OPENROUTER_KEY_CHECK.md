# OpenRouter credential verification — 2026-09-26

Authentication returned HTTP 200. A local key and ALLOW_PAID_RUNS=1 were present; the key was never displayed. The key's provider-side limit is USD 4; the project retains its stricter USD 3 and CAD 5 total ceilings.

One real native Deep Agents/SkillsMiddleware hand-authored canary ran on `qwen/qwen3.8-27b`, pinned to `darkbloom/fp4` (actual provider Darkbloom), with fallback disabled. It returned exactly the expected original UUID using the sole offered terminal `select_skills` tool. This is integration evidence, not a SkillRet benchmark.

Returned usage: 624 input + 65 output = 689 tokens, zero reported reasoning tokens. Actual cost: USD 0.00019448; estimated CAD 0.00029172 at the existing 1.50 planning factor. The persistent shared ledger has one settled request and no unresolved reservation.

The public endpoint advertises a 262144-token combined context window and a 32768-token output cap, with no separate prompt cap. Preflight now records that distinction and enforces combined input-plus-output capacity. A regression test verifies that oversized requests are still rejected and that the new model pin preserves the original pin. The full suite passed 39 tests.

Sanitized raw graph/HTTP traces are in `results/openrouter/credential_canary.jsonl` and `evidence/traces/`; the model snapshot and separate pin are retained. Repeat `.venv/bin/python scripts/check_openrouter.py` to reuse the identical recorded canary. This check ran no full comparison and no Flash-model canaries.
