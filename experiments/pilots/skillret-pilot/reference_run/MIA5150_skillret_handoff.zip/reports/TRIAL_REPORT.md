# MIA5150 SkillRet trial — saved experimental evidence

**Latest benchmark:** See [OpenRouter scaling results](OPENROUTER_SCALING.md) for N=50/250/1000 across five models and the original [N=50 pilot](OPENROUTER_MODELS.md). The original configuration below is preserved as historical evidence; its spending ledger is project-wide.

User-authorized local Ollama follow-up: **25 valid real selector decisions** and **11 native model-requested reads** are recorded separately in [OLLAMA_TRIAL_REPORT](OLLAMA_TRIAL_REPORT.md). The OpenRouter-only status and costs below retain their original scope.

**Original OpenRouter protocol: CONDITIONAL GO: offline feasibility established; live acceptance incomplete.** Real retrieval and native Deep Agents discovery work locally. The local key and ALLOW_PAID_RUNS=1 were absent, so the live stages remain blocked. This is a blocked pilot, not the successful live pilot defined in CODEX_TASK.md.

## First result and data

The first experiment, before any API spending, obtained **BM25 Recall@5 = 0.516667 (51.67%)**, a macro average over **200 fixed queries against all 6,006 skills**. Recall@10 = 0.576667; Completeness@5 = 0.375 (75/200 queries). All positive labels count, including multi-skill queries. This is neither selection accuracy nor skill-execution success.

SkillRet revision `6583d7d2ed07644d0fb8938ed8178f3a7dc42a12` has 6,006 skills, 4,392 queries and 7,187 qrels in test. Referential integrity, duplicate-ID and query/qrel disagreement checks passed. There are 205 duplicate readable names, handled with unique s-UUID frontmatter. No missing name/description/body/query text was observed. Observed source licenses: MIT 5,270; Apache-2.0 736. Dataset metadata and queries are Apache-2.0; retain original source attribution. See the [pinned card](../evidence/dataset_card.md), [inspection](../results/dataset_summary.json) and [manifest](../manifests/dataset.json).

The 200-query sample uses seed 42; 20 interleaved single/multiple-positive cases support the scaling pilot. The remaining 4,192 IDs are disjoint and reserved. Their schemas/labels were audited for integrity but their texts were not used for prompts, examples, embeddings or tuning. Public GitHub skills and synthetic requests do not establish production behavior; the corpus is heavily skewed toward Software Engineering.

## Retrieval protocols and results

All rows below use the same 200 queries / 6,006 documents. The full-document and capped-metadata rows are different representations and must not be presented as a method-only comparison.

| Retriever | Representation | Recall@5 | Recall@10 | Completeness@5 |
|---|---|---:|---:|---:|
| BM25 | full name &#124; description &#124; skill_md | 0.5167 | 0.5767 | 0.3750 |
| BM25 | common capped metadata | 0.6058 | 0.6858 | 0.4450 |
| BGE-small | common capped metadata; 512-token query limit | 0.4925 | 0.5225 | 0.3350 |

Full-document BM25 faithfully ports the CPU path in `skillret/eval.py:build_skill_text, eval_bm25`, Git commit `0cc508e6bfcfff1fe6352d90ff5957ba38a64bba`: full name/description/body, bm25s English stopwords, lowercase/default two-character regex, no stemming, Lucene BM25 k1=1.5/b=0.75, positive-score hits. Installed bm25s is 0.3.11; upstream lock has 0.3.3. Local metrics match the pinned evaluator on three known-answer controls (including empty and multi-positive rankings). MRR is a local addition. This is a **partial-protocol subset run, not reproduction of a published full benchmark score**. Source snapshot and parity evidence are included.

Matched metadata is original name + description, capped once to 1,024 characters then 128 BGE tokens (including special tokens), used identically by listing/BM25/vector/native metadata. 13 skills hit the character cap; 196 hit the subsequent token cap. BGE-small-en-v1.5 revision `5c38ec7c405ec4b44b94cc5a9bb96e735b38267a` runs on CPU, normalized 384-dimensional vectors, exact dot products, fixed documented query prefix. **7/200 query embeddings were truncated at 512 tokens**, with IDs saved in the embedding manifest. LLM query text is never truncated. Full-document baseline took 2.933 seconds; the recorded embedding stage took 67.731 seconds, including setup/download and encoding on this machine; neither is a forecast.

## Conditional distractor scaling

Current run: `2deb6bf7f644f9b1c3e4f8942b61866a5b362b0bc92e60c027a38e8caa370f2a`. Each query has nested gold-preserving libraries N=50/250/1000, random distractors and fixed ID-derived display order. This is a conditional scaling study, not a shared production catalogue or official full-corpus benchmark. Gold is used only by the sampler/evaluator. Retrieval uses only common metadata; the native StateBackend holds only candidates. Domain routing must see only canonical query text and the fixed six-major taxonomy, never query k/names/labels.

| N | Method | Real retrieval cases | Candidate recall |
|---:|---|---:|---:|
| 50 | listing | 20 | 1.0000 |
| 50 | bm25 | 20 | 0.9000 |
| 50 | vector | 20 | 0.8250 |
| 250 | listing | 20 | 1.0000 |
| 250 | bm25 | 20 | 0.8250 |
| 250 | vector | 20 | 0.7000 |
| 1000 | listing | 20 | 1.0000 |
| 1000 | bm25 | 20 | 0.7750 |
| 1000 | vector | 20 | 0.6500 |

Listing coverage is 1 by construction. Domain-vector results require a real LLM router; absent rows are unrun, never a gold-domain substitute or global fallback. See [single/multiple diagnostics](single_multi.csv). There are **0/240 valid live selector cases, 0 attempted live cases**. Conditional semantic accuracy and service reliability use their explicit per-method denominators in scaling.csv; they are not estimable with zero attempts. Missing selector results are not zeros. Offline scripted replies are excluded from semantic metrics.

## Native integration, disclosure and context

Real `create_deep_agent` and `SkillsMiddleware` from Deep Agents 0.7.19 loaded canonical SKILL.md frontmatter from an isolated StateBackend. The metadata-only graph removes filesystem tools via supported profile exclusions, disables the general-purpose subagent and summarization, and checks the actual effective schemas at every model boundary. Native loading, unique names, absence of body-only/noncandidate sentinels and terminal one-call handling passed. No host filesystem is mounted; skills are never executed.

Actual native read_file disclosure ran on **5 cases (two real SkillRet, three hand-authored fixtures)** using a scripted model. These verify native reading only. At most 100 lines / 12,000 returned characters per read, at most two reads and four model calls; truncation is explicit. Live activation has 0 recorded cases; zero means unrun/blocked. See [offline disclosure traces](../evidence/activation_offline.jsonl).

Effective native prompts for the real scaling candidates were inspected using a scripted empty terminal response. This is prompt preflight evidence only. Qwen's pinned tokenizer estimates below are not billed provider counts. Cost reserves use a conservative UTF-8 byte bound plus framing; context checks use the corresponding tokenizer estimate plus 10% and 1,024 tokens of framing margin (byte fallback for other models). That context estimate excludes 20 cases; this is not proof the provider would reject all of them. No catalogue is truncated, summarized or silently reduced.

| N | Method | Mean estimated input tokens | Conservative context exclusions |
|---:|---|---:|---:|
| 50 | listing | 7042 | 0/20 |
| 50 | bm25 | 1225 | 0/20 |
| 50 | vector | 1224 | 0/20 |
| 250 | listing | 33256 | 0/20 |
| 250 | bm25 | 1269 | 0/20 |
| 250 | vector | 1257 | 0/20 |
| 1000 | listing | 131385 | 20/20 |
| 1000 | bm25 | 1238 | 0/20 |
| 1000 | vector | 1230 | 0/20 |

## OpenRouter status, costs and failures

Public metadata currently permits pinning `qwen/qwen3-8b` to `alibaba`, fallback disabled. It advertises tools and auto tool choice, not forced terminal function selection. Temperature=0; maximum selector output=512, router output=96. Reasoning effort none is requested; actual behavior requires a live response. Wall time is workflow latency, never pure model generation throughput. Actual usage and reliability require completed live cases; absent values remain unavailable.

The native ChatOpenRouter adapter required small typed-SDK compatibility handling: provider max-price fields must be decimal strings, reasoning uses effort=none, and raw sanitized HTTP response capture preserves the provider field dropped by the SDK response schema. HTTP MockTransport tests inspect actual serialized requests, usage and completion IDs; they do not establish live compatibility. Explicit SDK retries=None plus max_retries=0 yields one transport attempt; transient failures are retained without automatic retry. Timeout is 90 seconds (90,000 ms at the SDK). A live canary remains required before any comparison.

Actual paid requests: **236**. Actual returned cost: **USD 0.386496**; unresolved reserves: USD 0.000000. Estimated CAD equivalent of actual cost: **CAD 0.579745**, using 1.50 CAD/USD as a planning assumption, not a verified exchange rate. Persistent file locking, request caps, pre-request byte/output reserves, both USD/CAD ceilings and retained ambiguous-failure reserves protect the local runner. They do not control unrelated account activity or bank fees. No future total is quoted as measured spend.

[Known failures](../evidence/KNOWN_FAILURES.md) preserve initial parsing, middleware, tokenizer and adapter-test failures. Earlier run configurations are retained but excluded from current aggregates. Latest test log: **54 passed in 6.81s**. Both notebooks must show executed outputs and a SKIPPED paid cell by default; notebook validation is in `evidence/notebook-execution.json`.

## Proposal decision and resume

The team has evidence for a narrow feasibility proposal. Live comparison claims require completed cases above; zero live cases means that milestone is incomplete. No result here supports a general superiority claim at scale.

Run `python3 setup_local_key.py` privately in this project, enter the key there and authorize the bounded trial. Then run `bash scripts/resume.sh`. The script runs guarded canary → five-query N=50 trial → bounded expansion → separate activation → tests/notebooks/report/package, stopping on nonzero status. Reopening notebooks never opts into paid calls; that requires a separate ALLOW_PAID_NOTEBOOK_RUNS=1 plus the normal key/permission/budget checks. A handoff needs Python 3.12, installed pinned dependencies, data/model downloads, a key and API credits for live stages; it is not an offline self-contained live benchmark.
