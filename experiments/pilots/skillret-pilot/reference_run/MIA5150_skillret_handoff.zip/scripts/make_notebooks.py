"""Create exactly two thin notebooks; execute separately with execute_notebooks.py."""
from pathlib import Path
import nbformat as n
ROOT=Path(__file__).resolve().parents[1]

def create(name,cells):
    b=n.v4.new_notebook(cells=[n.v4.new_markdown_cell(s) if kind=='md' else n.v4.new_code_cell(s) for kind,s in cells])
    b.metadata.kernelspec={'display_name':'Python 3 (project .venv)','language':'python','name':'python3'}
    b.metadata.language_info={'name':'python','version':'3.12'}
    n.validate(b);n.write(b,ROOT/name)

create('01_data_and_retrieval.ipynb',[
 ('md','# 1. Data and retrieval\n\n## tl;dr\nThe executed full-document BM25 baseline reached Recall@5 **0.516667** over **200 queries / 6,006 skills**. This is retrieval, not skill execution. Saved evidence is reused with checksum validation; shared functions own computation.'),
 ('md','## Context & Methods\n\nFixed seed 42 and immutable SkillRet revision. Full-document BM25 follows the pinned CPU source path; capped-metadata BM25/BGE form a separate matched comparison.\n\n### Key assumptions\nSynthetic queries, public skills, incomplete production validity. Metadata cap: 1,024 characters then 128 BGE tokens; seven vector queries exceed 512 encoder tokens. No prompts are tuned on the reserved final IDs.'),
 ('code','from pathlib import Path\nfrom pilot import ROOT, load_data, inspect_data, baseline, read_json, rows\nfrom trial import vectors\nimport pandas as pd'),
 ('md','## Data\n### 1. Verify real inputs and disjoint reservations'),
 ('code',"summary = inspect_data()\nassert set(read_json('manifests/pilot_query_ids.json')).isdisjoint(read_json('manifests/final_query_ids.json'))\n{'revision': summary['revision'], 'counts': summary['counts'], 'integrity': summary['checks']}"),
 ('md','### 2. Inspect consumed pilot examples only'),
 ('code',"examples = read_json('results/pilot_examples.json')\npd.DataFrame([{'query_id': x['query']['id'], 'canonical_query': x['query']['query'], 'positives_evaluator_only': len(x['query']['skill_ids'])} for x in examples])"),
 ('md','## Results\n### 3. Real BM25 number, with saved raw rankings'),
 ('code',"b = baseline(200)\nraw = [r for r in rows('results/baseline_rows.jsonl') if r['run_id'] == b['run_id']]\nindependent = sum(len({s for s, _ in r['ranking'][:5]} & set(r['evaluator_only_gold'])) / len(r['evaluator_only_gold']) for r in raw) / len(raw)\nassert abs(independent - b['metrics']['recall_at_5']) < 1e-12\n{'queries': len(raw), 'corpus_size': b['corpus_size'], 'recall_at_5': independent, 'recall_at_10': b['metrics']['recall_at_10']}"),
 ('md','### 4. Matched capped-metadata retrieval'),
 ('code',"embedding = vectors()\npd.DataFrame([{'method': name, 'queries': r['query_count'], **r['metrics']} for name, r in [('BM25 metadata', rows('results/metadata_bm25_summary.jsonl')[-1]), ('BGE-small metadata', rows('results/vector_baseline_summary.jsonl')[-1])]])"),
 ('md','## Takeaways\nThe pinned data and CPU retrieval path work. Matched-metadata BM25 Recall@5 is 0.605833 versus BGE-small 0.492500 in this exploratory sample. This does not establish a general winner. Preserve the 4,192 reserved final IDs. See reports/TRIAL_REPORT.md for limitations and distinct protocols.')])

create('02_deepagents_trial.ipynb',[
 ('md','# 2. Native Deep Agents trial\n\n## tl;dr\nNative metadata/tool isolation and actual native reads passed with scripted control. **Live OpenRouter integration is blocked by missing local key/permission.** No scripted response is a benchmark result. Paid cells require a separate opt-in.'),
 ('md','## Context & Methods\nUse the real create_deep_agent / SkillsMiddleware / StateBackend. Main mode offers only select_skills; activation separately permits bounded native read_file.\n\n### Key assumptions\nPer-query nested gold-preserving libraries are a conditional distractor study. The same selector, prompts and metadata apply to all methods. Gold remains outside model state.'),
 ('code','import os\nfrom agent_runner import offline_check, Blocked\nfrom trial import smoke, run_trial, activation_smoke\nfrom pilot import doctor, rows, read_json\nfrom handoff import report\nimport pandas as pd\nPAID_NOTEBOOK_RUNS = os.getenv("ALLOW_PAID_NOTEBOOK_RUNS") == "1"'),
 ('md','## Data\n### 1. Check local prerequisites without displaying secrets'),
 ('code',"status = doctor()\n{k: status[k] for k in ['python', 'env_file_present', 'key_present', 'paid_permission']}"),
 ('md','## Results\n### 2. Exercise the real native graph with scripted model control'),
 ('code','offline_check()'),
 ('md','### 3. Native SKILL.md disclosure, explicitly offline'),
 ('code','activation_smoke(live=False)'),
 ('md','### 4. Explicitly opt-in paid stages\nA fresh notebook never enables spending. ALLOW_PAID_NOTEBOOK_RUNS=1 is additional to ALLOW_PAID_RUNS=1, a local key and the persistent guard.'),
 ('code',"if not PAID_NOTEBOOK_RUNS:\n    paid_status = {'status': 'SKIPPED', 'reason': 'Paid notebook opt-in is disabled; live canary/trial not run in this notebook.'}\nelse:\n    try:\n        canary = smoke(live=True)\n        if not canary.get('canary_correct'):\n            raise Blocked('canary_failed')\n        comparison = run_trial(quick=True, live=True)\n        disclosure = activation_smoke(live=True)\n        paid_status = {'status': 'COMPLETED', 'comparison': comparison, 'disclosure': disclosure}\n    except Blocked as exc:\n        paid_status = {'status': 'BLOCKED', 'reason': str(exc)}\npaid_status"),
 ('md','### 5. Read report tables from persisted results'),
 ('code',"report_summary = report()\npd.read_csv('reports/scaling.csv')"),
 ('code',"from IPython.display import Image, display\ndisplay(Image(filename='reports/figures/candidate_recall.png'))"),
 ('md','## Takeaways\nOffline feasibility is established. Live canary, selector accuracy/cost, domain routing and live activation remain unverified until local setup and guarded resume. Zero API attempts does not imply zero semantic accuracy. See reports/TRIAL_REPORT.md and evidence/KNOWN_FAILURES.md.')])
