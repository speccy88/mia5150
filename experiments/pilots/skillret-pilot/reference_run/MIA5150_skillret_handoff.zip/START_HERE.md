# MIA5150 SkillRet pilot — start here

> **Latest benchmark (2026-09-26):** Read [OPENROUTER_SCALING](reports/OPENROUTER_SCALING.md) for the three-query, five-model N=50/250/1000 expansion. It reuses the earlier N=50 evidence, preserves all failures and retains the shared budget guard. The earlier [five-query pilot](reports/OPENROUTER_MODELS.md) and local Ollama results remain available.

This handoff contains the executed offline pilot, a separate local Ollama follow-up, and the five-model OpenRouter pilot using real Deep Agents. The original qwen3-8b configuration had no credentials at execution time; its historical report is not the status of the later paid model tests.

The first real result was **BM25 Recall@5 = 0.516667 (51.67%) on 200 fixed queries against all 6,006 skills**. Full-document Recall@10 was 0.576667. On the separate matched capped-metadata representation, BM25 Recall@5 was 0.605833 and BGE-small was 0.492500. These are retrieval metrics, not successful skill execution.

Read [TRIAL_REPORT](reports/TRIAL_REPORT.md), [PROPOSAL_NOTES](reports/PROPOSAL_NOTES.md) and [known failures](evidence/KNOWN_FAILURES.md). All reported numbers derive from saved raw result rows. Earlier authoring material and failed attempts are preserved.

## What actually ran

- Five revised OpenRouter canaries passed. Current follow-up: 79 selector attempts, 68 valid outputs, 32 exact sets; six gated cases and 15 unrun Qwen 27B cases after rate limits. Separate activation: 25 cases, 15 valid workflows, 16 actual native reads. See the current report for per-model denominators and costs.

- Pinned SkillRet download and integrity audit: 6,006 skills / 4,392 queries / 7,187 qrels.
- Full-document BM25, then local CPU BGE and matched-metadata BM25 on 200 reserved pilot queries.
- Listing coverage, BM25 and vector retrieval for 20 queries × N=50/250/1000; all 240 planned selector cases recorded with live prerequisites blocked. Domain-vector has no invented router result.
- Real Deep Agents 0.7.19 native metadata loading, restricted effective tools and candidate-only StateBackend checks.
- Actual native read_file calls on two real SkillRet cases and three fixtures, **with scripted model control**. This is native disclosure evidence, not a live activation result or skill execution.
- Tests through `python -m pytest -q` and both notebooks, with paid notebook cells explicitly skipped. Consult current validation evidence for exact counts/status.

## Recreate the local environment

Python 3.12 is required. No Docker, GPU, global installs or model training are needed.

```bash
uv venv --python python3.12 .venv
uv pip sync --python .venv/bin/python requirements.lock.txt
```

Without uv: `python3.12 -m venv .venv`, then `.venv/bin/python -m pip install -r requirements.lock.txt`.

The ZIP excludes `.env`, environments, raw dataset files, model weights and bulk caches. The pinned downloader, manifests and checksums are included. First reruns need network access and disk space for the local dependencies/data/embedding model. OpenRouter reruns additionally need credentials and API credits. The local alternative needs the installed Ollama models and running localhost service.

## Resume the paid trial privately

In your own terminal, inside this directory:

```bash
python3 setup_local_key.py
.venv/bin/python scripts/run_openrouter_models.py --stage all
```

The first command hides key input, creates a private `.env`, and asks locally whether to authorize the bounded paid trial. Never paste the key into chat. If `.env` already exists, edit it privately: set the key and `ALLOW_PAID_RUNS=1`; the helper never overwrites it.

The runner enforces **both USD 3 and CAD 5 ceilings**, a persistent 300-request cap and conservative per-request reserves. CAD conversion is the explicit 1.50 CAD/USD planning assumption, not a verified exchange rate. Limits may be lowered. Missing cost is unknown; unresolved charges retain reservations and stop expansion. Failed/finished cases are retained rather than automatically retried. Never delete the ledger to reset a spending limit.

The historical default candidate remains qwen/qwen3-8b / Alibaba. The current five-model runner uses explicit per-model configurations and provider pins, without fallback. Read its saved report for actual canary outcomes and reasoning behavior. Native ChatOpenRouter is retained with typed-SDK compatibility handling verified at the HTTP transport boundary. `--live` alone does not authorize payment. No alternative model is silently substituted.

## Simple CLI and outputs

Use `.venv/bin/python` below (or activate the venv and use `python`). A blocked live CLI exits 2; pytest retains its own nonzero status.

| Command | Principal outputs |
|---|---|
| `python pilot.py doctor` | `evidence/doctor.json`, presence booleans and installed versions only |
| `python pilot.py download` | `data/{skills,queries,qrels}.jsonl`, `manifests/dataset.json`, pinned dataset card |
| `python pilot.py inspect` | `results/dataset_summary.json`, pilot examples, pilot/live/final reservation files |
| `python pilot.py baseline --queries 200` | full-document `results/baseline_rows.jsonl`, `baseline_summary.jsonl` |
| `python pilot.py vectors` | pinned embedding manifest, local vectors, matched retrieval rows/summaries |
| `python pilot.py offline-check` | real native graph fixture trace in `evidence/native_offline_check.json` |
| `python pilot.py smoke --live` | live canary or `results/blockers.jsonl`; paid traces and ledger only if authorized |
| `python pilot.py run --quick --resume --live` | five queries, N=50; append-only trial rows and exact catalogue membership |
| `python pilot.py run --config pilot.defaults.json --resume --live` | up to 240 selector cases; raw sanitized traces, routes, costs, failures and context exclusions |
| `python pilot.py activation-smoke --live` | separate `results/activation.jsonl`; without `--live`, offline native read evidence |
| `python pilot.py report` | generated Markdown, CSVs, summary JSON and three figures under `reports/` |
| `python -m pytest -q` | console test results; `python scripts/verify.py` also retains the output/exit code |
| `python scripts/execute_notebooks.py` | both executed notebooks and `evidence/notebook-execution.json` |
| `python pilot.py package` | one current `dist/MIA5150_skillret_handoff.zip`, allowlist/secret-scan/checksum audit |

The runner always reuses already recorded matching live cases; `--resume` makes this intent explicit. Configuration hashes include dataset, representation, prompts, provider/settings, source and relevant package versions. Earlier configurations are preserved and excluded from current report aggregates. No failed selection is repeatedly sampled until correct.

## Two notebooks

1. `01_data_and_retrieval.ipynb`: data audit, examples, real baseline and matched metadata retrieval.
2. `02_deepagents_trial.ipynb`: native integration checks, separate disclosure, guarded opt-in canary/trial, saved results.

Both are thin wrappers over shared functions. Paid notebook execution requires the **additional** environment flag `ALLOW_PAID_NOTEBOOK_RUNS=1` as well as the usual local key/permission/budget guard. Leave it unset when opening or reviewing notebooks.

## Interpretation boundaries

The 200 pilot IDs are consumed. The 4,192 disjoint final IDs remain reserved from query-text inspection, embeddings and prompt development (full-data schema/label integrity was audited). The scaling study uses per-query nested libraries retaining gold positives and random distractors; listing coverage is therefore trivially 1. Public skills and synthetic queries have limited external validity. Seven vector query embeddings were explicitly truncated by the 512-token encoder limit; LLM catalogues/queries are never silently truncated. No p-values, published-score reproduction, general method superiority or execution-success claims are supported.

The team can write a feasibility-grounded proposal using the offline evidence and the separately reported local inference results. The original full scaling acceptance milestone remains incomplete; the five-model follow-up uses five queries at N=50. Local inference is a distinct provider/model protocol.

## Local Ollama alternative (user-authorized follow-up)

A separate local test path uses the installed `qwen3.5:4b-mlx` and `qwen3.5:9b-mlx` models through ChatOllama and the same native Deep Agents graph. It needs no OpenRouter key or paid opt-in. Model digests, real traces, errors and results are stored under the `ollama` evidence/results/manifests directories, leaving the original OpenRouter evidence separate.

```bash
.venv/bin/python pilot.py ollama-smoke
.venv/bin/python pilot.py ollama-run
.venv/bin/python pilot.py ollama-report
```

`ollama-run` is bounded to five existing pilot queries, N=50, listing/BM25/vector/domain-vector and separate disclosure checks. Add `--model qwen3.5:4b-mlx` or `--model qwen3.5:9b-mlx` to run one installed model. Matching cases are reused; failures are retained. The local path has a persistent 100-attempt cap, 90-second request timeout and no automatic retries. No weights are downloaded. See [local report](reports/OLLAMA_TRIAL_REPORT.md) and [CSV](reports/OLLAMA_RESULTS.csv) for actual outcomes.

Local notebook inference is also opt-in: `ALLOW_LOCAL_NOTEBOOK_RUNS=1`. The default notebook only reads saved local results. The local CLI exits 2 if the canary fails or fewer than all 20 planned selector cases are valid; this preserves partial/failed outcomes even when the experiment process itself ran correctly. `python scripts/audit_local.py` validates saved real wire traces without another model call.

Measured local outcome: 4B produced 15 valid selections from 18 attempts (20 planned); 9B produced 10 from 15 attempts (20 planned). Eight responses had invalid IDs; seven domain cases were gated. All six fixture activation workflows passed. Four real activation workflows failed guards, while three real candidate SKILL.md reads were observed in 9B traces. The suite has 38 passing tests; both notebooks execute. Local API charges are USD 0 / CAD 0; electricity and hardware costs were not measured.

## Five-model OpenRouter follow-up

Requested IDs: `qwen/qwen3.8-27b`, `qwen/qwen3.8-flash`, `deepseek/deepseek-v4.1-flash`, `xiaomi/mimo-v2.6-pro`, `z-ai/glm-5.3-flash`. See [measured report](reports/OPENROUTER_MODELS.md), [machine-readable summary](reports/OPENROUTER_MODELS.json), [case aggregates](reports/OPENROUTER_MODELS.csv), and `results/openrouter/<model>/` for raw sanitized records.

```bash
.venv/bin/python scripts/run_openrouter_models.py --stage canaries
.venv/bin/python scripts/run_openrouter_models.py --stage trial
.venv/bin/python scripts/run_openrouter_models.py --stage activation
.venv/bin/python scripts/report_openrouter.py
.venv/bin/python scripts/audit_openrouter.py
```

All stages are sequential, resumable by exact case identity, and retain failures. The runner exits 2 for incomplete or invalid stages. A failed output is not retried. Provider rate limits and mandatory reasoning are measured integration outcomes. For reviewing saved results, run only report/audit, which make no API requests. Keep the existing budget ledger; never clear it to restart spending.

## Scaling benchmark

```bash
.venv/bin/python scripts/benchmark_openrouter.py --live
.venv/bin/python scripts/report_scaling.py
.venv/bin/python scripts/audit_scaling.py
```

The scaling runner fixes the first three existing pilot queries and N=50/250/1000 across all five requested models. It explicitly reuses matching N=50 decisions and query-only routes. This 180-case study fits the remaining request cap; it is not the full 1,200-selector five-model sweep. Same native runner, prompts, model/provider settings and strict UUID validation apply. A transport failure pauses new cases for that model; unresolved billing pauses all paid calls. Existing failed cases are never retried for a better score.

Current outputs: [scaling report](reports/OPENROUTER_SCALING.md), [summary CSV](reports/OPENROUTER_SCALING.csv), [failure rows](reports/OPENROUTER_SCALING_FAILURES.csv), and `results/openrouter/scaling/`. Review report/audit commands spend no API credits. The notebook reads these saved results by default.
