# Trial acceptance checklist

Each item needs an observed artifact or an explicit BLOCKED/NOT RUN status. This list is for Codex to complete on the Mac; unchecked items are not claims of implementation.

## Data and baseline
- [ ] Dataset revision is an immutable resolved commit; all loads use it.
- [ ] Counts, schema, licence/provenance and actual examples are saved.
- [ ] Every gold ID maps to a skill; multi-positive queries are handled.
- [ ] Pilot-consumed queries are separated from the future untouched holdout.
- [ ] A real BM25 metric is printed with corpus/query counts and input representation.
- [ ] Published reproduction, partial-protocol check and local baseline are distinguished.
- [ ] Dense embeddings are from the stated model, not a placeholder; cache IDs/hashes match.

## Native Deep Agents integration
- [ ] Native SkillsMiddleware injected the expected candidate metadata.
- [ ] Source directory semantics are tested, including rejection of the old per-skill-path pattern.
- [ ] Duplicate readable skill names cannot silently override one another.
- [ ] No non-candidates, body-only content or gold labels appear in the main initial prompt.
- [ ] Main offered/executable tool set is only terminal select_skills.
- [ ] Two fresh runs cannot see each other's skill state/messages.
- [ ] A real OpenRouter canary returned a usable response with request ID and usage.
- [ ] Separate activation smoke includes a logged real SKILL.md read, not just a declared selection.
- [ ] Attempts to execute scripts, read host files, write files or call subagents are blocked.

## Cost, context and reproducibility
- [ ] Both currency guards and completion-count cap operate before paid calls.
- [ ] Missing key/permission forbids paid requests while preserving offline progress.
- [ ] Unknown/ambiguous billing does not become zero on restart.
- [ ] Unknown provider/price/context causes a useful preflight stop.
- [ ] No automatic model fallback, retries, context truncation or summary can alter the comparison unnoticed.
- [ ] The same case resumes without another charge; changed config cannot reuse incompatible outputs.
- [ ] Actual billed router reuse and logical per-workflow cost are distinguished.
- [ ] Seeded catalogues are nested, gold-preserving and identical across strategy comparisons.

## Evaluation and report
- [ ] Scores agree with the supplied known-answer controls and small hand checks.
- [ ] Unknown or duplicate predictions and malformed tool calls are retained as failures.
- [ ] Candidate retrieval recall and final selection quality are separate.
- [ ] Framework/API failures and semantic mistakes have separate diagnostics.
- [ ] Planned, attempted, valid and completed counts are visible; no success-only denominator.
- [ ] Report and figures are generated from persisted rows; no fabricated values fill gaps.
- [ ] Tests ran via python -m pytest with a collected-test count.
- [ ] Notebooks ran or visibly record skipped/blocked live cells without accidental new paid calls.
- [ ] One final ZIP preserves all related prompts/code/tests/evidence and excludes actual .env/secrets/caches.

## Minimum useful outcome

A real data audit + one real BM25 score is a useful first result. Calling the **agent pilot working** additionally requires the real OpenRouter/Deep Agents selection and activation checks. The full 240-selector sweep is not required when a smaller completed trial establishes feasibility within the approved limits.
