# Preserved failures and corrections

- `inspection.log`: initial exit 1 from using `str.splitlines()` for JSONL containing Unicode U+2028 inside a quoted skill string. Fixed to split only LF; original data unchanged. `inspection-02.log` records the passing audit.
- `native-check-01.txt`: initial graph construction exit 1. The installed FilesystemMiddleware requires a read tool; metadata mode now excludes it through the supported HarnessProfile. Effective tools are asserted at the model boundary.
- `pytest-01.log`: 28 passed, 2 failed, exit 1. Wire-level tests found that numeric max-price fields caused the SDK to drop provider restrictions and that `reasoning.enabled` was not represented by its schema. The native ChatOpenRouter subclass now validates typed provider preferences, uses exact decimal strings for prices and `reasoning.effort=none`, and sets SDK retries explicitly to None. The fixture response also needed the SDK-required `system_fingerprint` field.
- Initial quick/full offline runs recorded `input_tokens_estimated=2` because Transformers 5 returned a BatchEncoding and the implementation counted keys. Corrected to count input_ids. Earlier rows/traces remain, are superseded by the final configuration, and must not be used for token estimates. Retrieval rankings were unaffected. The separate UTF-8 byte reserve was unaffected and no paid call occurred.
- No OpenRouter credential or ALLOW_PAID_RUNS=1 was available. Blocked live requests are prerequisites failures, not transport attempts or semantic failures. No model fallback was made.
- `pytest-02.log`: 29 passed, 1 failed, exit 1. The SDK response schema discarded the provider field. Sanitized HTTP response capture now preserves that field without inferring the actual provider. `pytest-03.log` passed all 30 controls. These transport checks used mocked HTTP, not paid calls.
- `package-command.log`: initial package command exited 1 before creating an archive because the PEM scanner matched its own literal marker. Corrected to require a PEM header followed by a base64 body line. This is a scanner self-match correction, not an exemption for source files or credentials.

## Local Ollama follow-up

- See [local evidence notes](ollama/README.md), raw responses and append-only local result rows. The initial adapter argument error and native content-block TypeError happened before HTTP; both were fixed and retained.
- Initial model canaries and later real comparisons include rejected s-prefixed UUIDs. One fixture-only contract clarification was made; later invalid selections were never corrected or retried. The early local CLI returned exit 0 with a failed canary status; the CLI now exits 2 for failed canaries or incomplete planned selection coverage.
- The 4B model requested parallel reads on its first real activation query. The execution guard rejected them before disclosure. Per-case failures and unattempted remaining cases are distinct. The complete local results report is generated from saved rows.

## OpenRouter five-model follow-up

- Initial Qwen3.8 Flash and DeepSeek V4.1 Flash canaries: unknown_ids (returned native s- names). Retained before fixed common UUID clarification v2; no output repair.
- Initial GLM5.3 Flash canary: HTTP 400, reasoning mandatory. Zero charge reconciled against provider key usage; explicit effort=low used in the revised configuration.
- Qwen3.8 27B / Darkbloom listing requests: upstream shared-pool HTTP 429. Two distinct cases failed; small BM25/vector prompts succeeded. Remaining selection expansion paused for this provider limitation; no failed case retried.
- First attempt to reconcile the second 429 exited 1 because key cumulative usage lagged ledger costs. Reservation stayed outstanding and the batch refused paid continuation. A later recorded usage check reconciled it.
- All later selector/activation outcomes, including invalid IDs, malformed output and read-policy denials, are generated in reports/OPENROUTER_FAILURES.csv from append-only saved rows. Nonzero stage exits are preserved in evidence/openrouter_stages.jsonl.

## Scaling expansion

Qwen3.8 27B / Darkbloom: one new N=250 listing request failed with upstream HTTP 429. The budget guard stopped all paid work until zero charge was reconciled against key usage. The scaling scheduler preserves that failure and pauses remaining new cases for this model; cached N=50 outcomes remain intact. Other model outputs, invalid IDs and gated domain cases are retained in results/openrouter/scaling and generated OPENROUTER_SCALING_FAILURES.csv. No automatic retry, ID repair, provider switch, or context truncation was used.

MiMo/DeepInfra later returned HTTP 429 with provider_error_code=engine_overloaded, upstream_provider_shared_pool, no generation ID. The strict reconciliation helper initially rejected this new error signature and exited 1, preserving its reserve. It now recognizes this explicit pre-generation shared-pool variant as well as rate_limit_exceeded, while still requiring provider key usage to equal settled charges. An immediate key-usage check lagged the final MiMo generation; no additional paid requests were allowed during that discrepancy.
