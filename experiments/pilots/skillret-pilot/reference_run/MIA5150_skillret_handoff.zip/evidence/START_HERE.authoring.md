# START HERE — MIA5150 Skill Discovery two-day trial

## What this ZIP is

A complete **Codex implementation-and-execution handoff** for your empty Mac project, plus small tested scoring/sampling utilities and a private local-key helper. Codex is to create the runnable Deep Agents/OpenRouter experiment, download SkillRet, execute the pilot, and preserve its evidence.

**This is not an already completed live benchmark.** No OpenRouter key was supplied to the authoring environment. Real SkillRet downloads and a Deep Agents installation were not executed here. Fourteen standard-library helper tests were executed through pytest; that validates only the bundled helper functions, not the future agent integration. See `evidence/AUTHORING_CHECKS.md`.

## Start on your Mac

1. Extract this ZIP. Use the extracted directory as the project folder, or put it inside your currently empty project.
2. In Codex, paste the prompt below. It can start setup, data loading and the local baseline before you enter a key.
3. When ready for paid API calls, run `python3 setup_local_key.py` **yourself in a normal terminal inside this directory**. The prompt hides input and creates a private `.env`; no key should be pasted into Codex/ChatGPT. Confirm the bounded spending permission locally. If `.env` already exists, the helper refuses to overwrite it: edit it privately instead.

The default proposed spending guards are **CAD 5** and a separate **USD 3** native ceiling. CAD conversion uses **1.50 CAD/USD as an explicit planning assumption**, not a live exchange rate. Limits can be lowered before running. A dedicated OpenRouter key with a provider-side limit is also prudent. These are not predictions of actual cost.

### Paste this into Codex

```text
Locate CODEX_TASK.md in the current workspace and treat its containing directory as the project root. Read START_HERE.md, AGENTS.md, CODEX_TASK.md, SOURCE_NOTES.md, and pilot.defaults.json.

Implement and actually execute the MIA5150 two-day SkillRet skill-discovery trial described there. Use LangChain Deep Agents' real skill middleware, my locally configured OpenRouter credentials, and the real pinned SkillRet dataset. Keep the implementation small and understandable; create the two notebooks and simple CLI specified in the task.

Begin with data inspection and a real BM25 baseline number before using API credits. Then verify native skill loading and tool isolation, run a small OpenRouter canary, and expand to the bounded listing/BM25/vector/domain-vector trial only when the prerequisites work. Separately demonstrate an actual SKILL.md read. Do not replace Deep Agents with a hand-written prompt list and call it the same experiment.

Proceed with routine reversible work inside this project. Never display or read my .env through chat-visible tools, never execute downloaded skill instructions, and never make paid calls without ALLOW_PAID_RUNS=1 and the persistent budget guard. When the key or permission is missing, finish the offline stages and tell me the exact local setup/resume action rather than asking for the key in chat.

Do not stop after writing code. Run tests and the feasible real experiments, save raw sanitized traces and failures, and build the report from saved results. Preserve earlier evidence. Finish with the actual baseline metric and denominator, live integration status, actual/estimated cost, blockers, and one complete sanitized handoff ZIP. Never invent an unrun result or call a mock test a real benchmark.
```

## What Codex is expected to produce

| Milestone | Evidence |
|---|---|
| Real data opens | Pinned revision, observed counts, actual examples, provenance/licence summary. |
| CPU baseline works | Real BM25 retrieval metric with corpus/query counts and protocol. |
| Agent integration works | Native skill metadata in the captured prompt; actual OpenRouter request and usage. |
| Small comparison runs | Same selector across discovery methods; correct single-/multi-skill scoring. |
| Progressive disclosure works | Separate trace of a real candidate SKILL.md being read. |
| Proposal feasibility is assessed | Report, charts, costs, failures, reproducible commands and one sanitized ZIP. |

A complete small trial is more useful than an unfinished large sweep. Planned upper bound: 20 queries × 3 library sizes × 4 strategies = 240 selector decisions, plus router and smoke calls. Context, budget and availability may reduce the completed set; the report must show this rather than manufacture results.

## Key design decisions

- Primary experiment: **metadata-only selection**, using native Deep Agents discovery. This isolates discovery from arbitrary skill execution.
- Separate activation smoke: permit a bounded `read_file` call to verify real progressive disclosure.
- Full-document BM25 baseline and metadata-only scaling study have **different protocols**; keep their tables distinct.
- Real SkillRet data is downloaded on the Mac and pinned, not embedded in this handoff.
- Primary library sizes: 50, 250 and 1,000. Candidate shortlist: five. Domain routing uses the `major` taxonomy.
- Each query's smaller library is nested inside its larger one and retains its labelled relevant skills. This is a conditional distractor-scaling study, not a shared production library.
- The embedding model runs locally on CPU. The selector runs through OpenRouter, so no large local LLM/GPU installation is needed for this proposed pipeline.
- Suggested Qwen3-8B model ID is a preflight candidate. Availability/provider/tool support must be verified before the run.
- No knowledge graph, skill chains, training, or app dashboard in the two-day trial.

## Included now versus created later

**Included:** task prompt, persistent project rules, proposed configuration, source checks, private key helper, reference scoring/sampling functions, 14 helper tests, and authoring validation evidence.

**Created by Codex:** environment/lock, actual data loader, BM25/vector integration, Deep Agents runner, budget/usage logger, two notebooks, live results, charts, trial report, proposal notes and final ZIP.

The helper tests can be rerun without the agent stack using:

```bash
python3 -m unittest discover -s tests -v
```

After Codex installs pytest, the required test invocation is:

```bash
python -m pytest -q
```

Do not present helper-test success as proof that the live benchmark worked.
