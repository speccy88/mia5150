# Local Ollama evidence

This is the user-authorized local alternative to the original OpenRouter trial.
No paid model API is called. Real SkillRet documents remain untrusted data.

- `inventory-*.json` and `loaded-state-*.json`: localhost model metadata, installed digests and observed context. No models were downloaded.
- `requests.jsonl`: effective native graph messages and tools before each attempt.
- `responses.jsonl`: sanitized serialized HTTP request, raw Ollama response, usage, timing and failures. No HTTP headers or credentials are recorded.
- `trial-command-*.log`: real CLI output and exit status. Exit 2 denotes an incomplete/failed planned comparison, not fabricated success.
- `audit-*.json`: read-only validation of saved real wire payloads, candidate paths, canonical queries, metric arithmetic and bounded native reads.
- `implementation_failures.jsonl`: local errors that occurred before an HTTP generation request.

The persistent local attempt ledger is `results/ollama/requests.jsonl`; the limit
is 100 attempts across restarts. Canary, comparison, routing and activation rows
have separate append-only files under `results/ollama/`. Model/configuration
manifests are under `manifests/ollama/`. Client-assigned UUIDs join the traces;
Ollama does not return a provider completion ID in these responses.

The first adapter attempt used an unsupported top-level `num_predict` argument
and failed before HTTP. Both initial real canaries then selected the correct
fixture but returned `s-` prefixed IDs, which were rejected. One documented local
prompt/schema revision clarifies UUID formatting without changing the native
skill list or correcting model output. A content-block handling error in that
revision also occurred before HTTP and was fixed. Earlier traces remain intact.

All methods within each model use the same revised prompt, settings and strict
ID validation. Invalid outputs are not retried. An invalid prerequisite skips
that query's domain-vector arm. Activation is separate: actual `read_file`
calls disclose candidate text; they never execute skill instructions. A guard
failure stops the affected model's remaining activation sequence.

Transport fixtures under `tests/` verify code only. Model accuracy is calculated
only from real saved inference in `reports/OLLAMA_TRIAL_REPORT.md`, with validity,
attempted and planned denominators. The five-query N=50 follow-up is exploratory
and cannot establish general model or retrieval-method superiority.

`derived_native_reads.json` reconstructs completed reads from the saved native tool-result messages when a later guard abort left the structured read list empty. It is derived evidence, not a new run. The 9B model read one real candidate before a denied offset=100 pagination request, then two candidates in the other real case before a denied out-of-candidate path. All three reads were within the initial 100-line window. Both workflows remain failed. A subsequent explicit resume attempted only the previously unattempted final cases; a further replay added zero model requests.
